const express=require('express');
const cors=require('cors');
const app=express();
const port=8000;
const models=require('./models');
const multer=require('multer');
const upload=multer({
    storage: multer.diskStorage({
        destination :function(req, file, cb){
            cb(null, 'uploads/');
        },
        filename: function(req, file, cb){
            cb(null, file.originalname);
        },
    }),
});


//실행될 앱에 대한 설정
app.use(express.json());
// json 형식을 expres에서 처리할때 사용
app.use(cors());
// cors형식을 사용하기위해서 적용
app.use("/uploads", express.static("uploads"));
// 서버에서는 uplodas 폴더에 존재하는 파일을 보여줄때 우리가 입력한 경로와 다른 경로를 보여준다. 이를 우리가 보는 경로로 세팅하기 위해서 사용한다.

app.get("/banners", (req,res)=>{
    models.Banner.findAll({
        limit: 2,
      })
        .then((result) => {
          res.send({
            banners: result,
          });
        })
        .catch((error) => {
          console.error(error);
          res.status(500).send("에러가 발생했습니다");
        });
});

app.get("/products",(req,res)=>{
    models.Product.findAll({
        // limit:1, // 찾을 데이터의 제한을 가하기 위해서 사용(ex) 1개의 데이터만 표현해라)
        order : [['createdAt','DESC']], // 기준열을 오름차순 혹은 내림차순으로 정렬한다.
        attributes: ['id','name','price','createdAt','seller','imageUrl','soldout'], // 다수의 칼럼들 중 원하는 칼럼만 선택하여 데이터를 보고자 할때 사용한다.
    }).then((result)=>{
        console.log("PRODUCTS : ",result);
        res.send({
            products : result
        })
    }).catch((error)=>{
        console.error(error);
        res.status(400).send("에러발생");   
    })
    // const query=req.query;
    // console.log('QUERY : ', query);
    // res.send({
    //     "products" : [
    //         {
    //             "id" : 1,
    //           "name": "농구공",
    //           "price": 100000,
    //           "seller": "조던",
    //           "imageUrl": "images/products/basketball1.jpeg"
    //         },
    //         {
    //             "id": 2,
    //           "name": "축구공",
    //           "price": 50000,
    //           "seller": "메시",
    //           "imageUrl": "images/products/soccerball1.jpg"
    //         },
    //         {
    //             "id" : 3,
    //           "name": "키보드",
    //           "price": 10000,
    //           "seller": "그랩",
    //           "imageUrl": "images/products/keyboard1.jpg"
    //         }
    //   ]
    // });
});
// get방식으로 정보를 요청할때 응답을 해준다

app.post("/products",(req,res)=>{
    const body=req.body;
    const {name, description, price, seller, imageUrl}=body;
    if (!name || !description || !price || !seller || !imageUrl) {
        res.status(400).send("모든 필드를 입력해주세요");
      }
    models.Product.create({
        name,
        description,
        price,
        seller,
        imageUrl,
    }).then((result)=>{
        console.log("상품생성 결과 : ",result)
        res.send({
            result,
        });
    }).catch((error)=>{
        console.error(error);
        res.status(400).send("상품 업로드에서 문제가 발생했습니다.");
    });
});
// post방식으로 정보를 요청할때 응답을 해준다

app.get("/products/:id", (req,res)=>{
    const params=req.params;
    const {id}=params;
    models.Product.findOne({
        where : { // 조건에 맞는 데이터를 조회시키기 위해서 where을 사용한다.
            id : id,
        },
    }).then((result)=>{
        console.log("PRODUCT : ",result);
        res.send({
            product : result,
        });
    }).catch((error)=>{
        console.error(error);
        res.status(400).send("상품조회에 에러가 발생했습니다.");
    })
});
// get 방식으로 데이터를 전달하며 


app.post('/image', upload.single('image'),(req,res)=>{
    const file=req.file;
    console.log(file);
    res.send({
        imageUrl:file.path,
    })
});

app.post("/purchase/:id", (req,res)=>{
    const {id}=req.params;
    models.Product.update({
        soldout : 1
    },{
        where:{
            id 
        },
    }
    ).then((resutl)=>{
        res.send({
            result : true,
        });
    }).catch((error)=>{
        console.error(error);
        res.status(500).send('에러가 발생했습니다.')
    })
});



app.listen(port, ()=>{
    console.log("그랩의 쇼핑몰 서버가 돌아가고 있습니다");
    models.sequelize
        .sync()
        .then(() => {
            console.log('DB 연결 성공!');
        })
        .catch((err) => {
            console.error(err);
            console.log('DB 연결 에러');
            process.exit();
        });  
});