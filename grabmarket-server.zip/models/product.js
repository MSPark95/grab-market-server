module.exports = function(sequelize, DataTypes){
    const product = sequelize.define('Product',{
        name :{
            type: DataTypes.STRING(20), // name열에는 문자열만 들어가야하며 20글자를 넘으면 안된다.
            allowNull:false // name이라는 열에 빈값을 허용하지 않는다는 의미
        },
        price:{
            type: DataTypes.INTEGER(10),
            allowNull: false
        },
        seller:{
            type : DataTypes.STRING(30),
            allowNull:false
        },
        description:{
            type:DataTypes.STRING(300),
            allowNull:false
        },
        imageUrl:{
            type : DataTypes.STRING(300),
            allowNullL:false
        },
        soldout : {
            type : DataTypes.INTEGER(1),
            allowNull:false,
            defaultValue:0,
        }
    });
    return product;
}