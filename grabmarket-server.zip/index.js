var http=require('http');
var hostname='127.0.0.1';
var port=8000;

// http.createServer(function(req,res){
//     res.writeHead(200,{'Contetn-Type':'text/plain'});
//     res.end('Hello Larry');
// }).listen(port,hostname);

// console.log('Server running at http://'+hostname+':'+port);

// const server=http.createServer(function(req,res){
//     console.log('REQEUST : ',req);
//     res.end('Hello Client!');
// });

// server.listen(port, hostname);

// console.log('grab market server on!'); // 기본적인 node.js 서버 연습

const server=http.createServer(function(req,res){
    const path=req.url;
    const method=req.method;
    if(path==='/products'){
        if(method==="GET"){
            res.writeHead(200, {'Content-type':'application/json'});
            const products=JSON.stringify([{
                name:"농구공",
                price:5000
                },
            ]);
            res.end(products)
        }else if(method==='POST'){
            res.end('생성되었습니다!');
        }
    }
    res.end("GOOD BYE")
});

server.listen(port, hostname); // Server를 생성하고 경로 및 연결방법(GET or Post)을 설정하여서 데이터를 주고받는 간단한 예시